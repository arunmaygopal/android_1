package com.example.my_actual_first_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
